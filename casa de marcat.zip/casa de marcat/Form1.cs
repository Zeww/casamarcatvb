﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Double resultValue = 0;
        Double resultttValue = 12; 
        String operationPerformed = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void button_click(object sender, EventArgs e)
        {
            if (textBox_Result.Text == "0")
                textBox_Result.Clear();

            Button button = (Button)sender;
            textBox_Result.Text = textBox_Result.Text + button.Text;
        }



        int a = 0;

        private void button15_Click(object sender, EventArgs e)
        {
          
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox3.Text);
            

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox4.Text);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox5.Text);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox6.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            a = 0;
            listBox1.Items.Clear();
            textBox2.Clear();
            textBox_Result.Clear();
            txt.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.RemoveAt(listBox1.SelectedIndices[0]);
            resultttValue = Double.Parse(textBox2.Text);

            textBox2.Text = (resultttValue - Double.Parse(textBox1.Text)).ToString();



            a--;
        }

        private void button30_Click(object sender, EventArgs e)
        {
            textBox_Result.Clear();
            txt.Clear();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }

        private void txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Sigur doriti sa faceti plata cu cardul?", "Credit Card", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                a = 0;
                listBox1.Items.Clear();
                textBox2.Clear();
                textBox_Result.Clear();
                txt.Clear();
            }

            else if (dialog == DialogResult.No)
            {
               
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.timer1.Start();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button19_Click(object sender, EventArgs e)
        {
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox8.Text);
        }

        private void button31_Click(object sender, EventArgs e)
        {

        }

        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operationPerformed = button.Text;
            resultValue = Double.Parse(textBox_Result.Text);
         
            switch (operationPerformed)
            {

                case "Calculeaza":
                    txt.Text = (resultValue - Double.Parse(textBox2.Text)).ToString();
                    break;

            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.Increment(1);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox9.Text);
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox10.Text);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox11.Text);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            a++;
            a++;
            a++;
            textBox2.Text = a.ToString();
            listBox1.Items.Add(textBox12.Text);
        }
    }
}
